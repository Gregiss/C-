﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simuladorConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            dominio.Menu m = new dominio.Menu();
            m.opcoes();
        }
    }
}
