﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simuladorConsole.dominio
{
    class Menu
    {
        conta acc = new conta();
        public void opcoes()
        {
            int opcao = 0;
            bool error = true;
            String[] options = new String[] { "Depositar", "Sacar", "Extrato", "Sair" };
            while (error)
            {
                Console.WriteLine($"Seu saldo R${this.acc.mostrarSaldo()} \n");
                Console.WriteLine("Oque você quer fazer?\n");
                for (var i = 0; i < options.Length; i++)
                {
                    Console.WriteLine($"{i + 1}: {options[i]} \n");
                }
                opcao = Convert.ToInt32(Console.ReadLine());
                if (opcao > options.Length || opcao < 0)
                {
                    error = true;
                    Console.WriteLine("Opção invalida :/");
                }
                else
                {
                    error = false;
                }
                Console.Clear();
            }
            if(opcao == 1)
            {
                this.depositar();
            } else if(opcao == 2)
            {
                this.sacar();
            } else if(opcao == 3)
            {
                this.extrato();
            } else if(opcao == 4)
            {
                Environment.Exit(1);
            }
        }

        public void depositar()
        {
            Console.WriteLine("Qual valor que queres depositar?");
            double valor = Convert.ToDouble(Console.ReadLine());
            acc.depositar(valor);
            Console.Clear();
            this.opcoes();
        }

        public void sacar()
        {
            Console.WriteLine("Qual valor que queres sacar?");
            double valor = Convert.ToDouble(Console.ReadLine());
            acc.sacar(valor);
            Console.Clear();
            this.opcoes();
        }

        public void extrato()
        {
            acc.extrato();
            Console.Clear();
            this.opcoes();
        }

    }
}
