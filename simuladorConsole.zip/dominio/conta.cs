﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simuladorConsole.dominio
{
    class conta
    {
        private double saldo = 0;
        public List<string> lista = new List<string>();

        public void sacar(double valor)
        {
            if(this.saldo < valor)
            {
                Console.WriteLine("Ocorreu um erro, suas economias não correspodem ao que queres sacar");
                Console.WriteLine("Clique uma tecla para continuar");
                Console.ReadLine();
            }
            else
            {
                this.saldo -= valor;
                lista.Add($"Você sacou R${valor} ");
                Console.WriteLine($"Que legal, você sacou R${valor}, te vejo em breve, eu espero :D");
                Console.WriteLine("Pressione uma tecla para continuar");
                Console.ReadLine();
            }
        }

        public void depositar(double valor)
        {
                this.saldo += valor;
                lista.Add($"Você depositou R${valor} em sua conta");
                Console.WriteLine($"Que legal, você depositou  R${valor} em sua conta, te vejo em breve, eu espero :D");
                Console.WriteLine("Pressione uma tecla para continuar");
                Console.ReadLine();
        }

        public void extrato()
        {
            Console.WriteLine($"Seu saldo atual é de R${this.saldo} ");
            foreach (String extrato in this.lista)
            {
                System.Console.WriteLine(extrato);
            }
            Console.WriteLine("Pressione uma tecla para continuar");
            Console.ReadLine();
        }
    }
}
