﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simuladorConsole.dominio
{
    class conta
    {
        private double saldo = 0;
        public List<string> lista = new List<string>();

        public void sacar(double valor)
        {
            if(this.saldo < valor)
            {
                Console.WriteLine("Ocorreu um erro, suas economias não correspodem ao que queres sacar");
                Console.WriteLine("Clique uma tecla para continuar");
                Console.ReadLine();
            }
            else
            {
                this.saldo -= valor;
                lista.Add($"Você sacou R${valor} ");
                Console.WriteLine($"Que legal, você sacou  {valor}, te vejo em breve, eu espero :D");
            }
        }

        public void depositar(double valor)
        {
                this.saldo += valor;
                lista.Add($"Você depositou R${valor} em sua conta");
                Console.WriteLine($"Que legal, você depositou  {valor} em sua conta, te vejo em breve, eu espero :D");
        }

        public void extrato()
        {
            Console.WriteLine($"Seu saldo atual é de ${this.saldo} ");
            foreach (String extrato in this.lista)
            {
                System.Console.WriteLine(extrato);
            }
            Console.WriteLine("Pressione uma tecla para continuar");
            Console.ReadLine();
        }
    }
}
