﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Agencia
    {
        private string Codigo { get; set; }
        private string Endereco { get; set; }
        private string Nome { get; set; }
        private Banco Banco { get; set; }


        public void registrar()
        {
            Console.WriteLine($"Qual o nome da Agencia?");
            this.Nome = Console.ReadLine();
            Console.WriteLine($"Qual o endereco da {this.Endereco}?");
            this.Nome = Console.ReadLine();
            this.Codigo = "01";
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("AGÊNCIA");
            sb.AppendLine("Código: " + Codigo);
            sb.AppendLine("Endereco: " + Endereco);
            sb.AppendLine("Nome: " + Nome);
            sb.AppendLine("Banco: " + Banco);
            return sb.ToString();
        }
    }
}
