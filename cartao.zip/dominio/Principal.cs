﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Principal
    {

        public void cadastrarBanco()
        {
            Boolean continua = true;
            var decisao = "no";
            int codigo = 0;
            while (continua)
            {
                Console.WriteLine("Você está registrando um banco");
                Banco b = new Banco();
                b.registrar();
                Console.WriteLine("Você deseja cadastrar mais um banco?\n yes or no");
                decisao = Console.ReadLine();
                if (decisao.Equals("yes"))
                {
                    continua = true;
                }
                else
                {
                    continua = false;
                }
            }
        }

        public void cadastrarAgencia()
        {
            Boolean continua = true;
            var decisao = "no";
            int codigo = 0;
            while (continua)
            {
                Console.WriteLine("Você está registrando um agencia");
                Agencia ag = new Agencia();
                ag.registrar();
                Console.WriteLine("Você deseja cadastrar mais uma agencia?\n yes or no");
                decisao = Console.ReadLine();
                if (decisao.Equals("yes"))
                {
                    continua = true;
                }
                else
                {
                    continua = false;
                }
            }
        }

        public void cadastrarCliente()
        {
            Boolean continua = true;
            var decisao = "no";
            int codigo = 0;
            while (continua)
            {
                Console.WriteLine("Você está registrando um Cliente");
                Cliente c = new Cliente();
                c.registrar();
                Console.WriteLine("Você deseja cadastrar mais um cliente?\n yes or no");
                decisao = Console.ReadLine();
                if (decisao.Equals("yes"))
                {
                    continua = true;
                }
                else
                {
                    continua = false;
                }
            }
        }

        public void cadastrarConta()
        {
            Boolean continua = true;
            var decisao = "no";
            int codigo = 0;
            while (continua)
            {
                Console.WriteLine("Você está registrando um CONTA");
                Conta conta = new Conta();
                conta.registrar();
                Console.WriteLine("Você deseja cadastrar mais uma conta?\n yes or no");
                decisao = Console.ReadLine();
                if (decisao.Equals("yes"))
                {
                    continua = true;
                }
                else
                {
                    continua = false;
                }
            }
        }

        public void cadastrarCartaoDeCredito()
        {
            Boolean continua = true;
            var decisao = "no";
            int codigo = 0;
            while (continua)
            {
                Console.WriteLine("Você está registrando um cartão de crédito");
                CartaoDeCredito cdc = new CartaoDeCredito();
                cdc.registrar();
                Console.WriteLine("Você deseja cadastrar mais uma cartão de crédito?\n yes or no");
                decisao = Console.ReadLine();
                if (decisao.Equals("yes"))
                {
                    continua = true;
                }
                else
                {
                    continua = false;
                }
            }
        }


        public void navegar()
        {
            menu();
        }


        public void menu()
        {
            String oque = "";
            while (true)
            {
                Console.WriteLine("Oque você quer fazer?\nOpções ?\n1:Cadastrar banco\n2:Cadastrar agencia\n3:Cadastrar cliente\n4:Cadastrar conta\n5:Cadastrar Cartão de crédito");
                oque = Console.ReadLine();
                if (oque.Equals("1"))
                {
                    cadastrarBanco();
                } else if (oque.Equals("2"))
                {
                    cadastrarAgencia();
                } else if (oque.Equals("3"))
                {
                    cadastrarCliente();
                } else if (oque.Equals("4"))
                {
                    cadastrarConta();
                }
                else if (oque.Equals("5"))
                {
                    cadastrarCartaoDeCredito();
                }
                else
                {
                    Console.WriteLine("Opção invalida");
                }
            }
        }

    }
}
