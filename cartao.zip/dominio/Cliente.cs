﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Cliente
    {
        private string Nome { get; set; }
        private string CPF { get; set; }
        private string RG { get; set; }

        public void registrar()
        {
            Console.WriteLine($"Qual o nome?");
            this.Nome = Console.ReadLine();
            Console.WriteLine($"Qual o CPF de {this.Nome}?");
            this.CPF = Console.ReadLine();
            Console.WriteLine($"Qual o RG de {this.Nome}?");
            this.RG = Console.ReadLine();
        }

        public String getNome()
        {
            return this.Nome;
        }

    }
}
