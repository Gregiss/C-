﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Conta
    {
        public string Numero { get; set; }
        public string DigitoVerificador { get; set; }
        public decimal Saldo { get; set; }
        private Cliente Titular { get; set; }

        public void registrar()
        {
            Console.WriteLine($"Qual o numero da conta?");
            this.Numero = Console.ReadLine();
            Console.WriteLine($"Qual o Digito verifador?");
            this.Saldo = 0;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CONTA CORRENTE");
            sb.AppendLine("Número: " + Numero + "/" + DigitoVerificador);
            sb.AppendLine("Saldo: " + Saldo.ToString("###,###,##0.00"));
            sb.AppendLine("Titular: " + this.Titular.getNome());
            return sb.ToString();
        }
    }
}
