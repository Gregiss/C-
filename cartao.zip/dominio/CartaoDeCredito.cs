﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class CartaoDeCredito
    {
        public string Numero1 { get; set; }
        public string Numero2 { get; set; }
        public string Numero3 { get; set; }
        public string Numero4 { get; set; }
        public string Numero
        {
            get
            {
                return $"{Numero1} {Numero2} {Numero3} {Numero4}";
            }
        }
        public string CVC { get; set; }
        public int MesVencimento { get; set; }
        public int AnoVencimento { get; set; }
        public string Vencimento
        {
            get
            {
                return $"{MesVencimento}/{AnoVencimento}";
            }
        }

        public Cliente Cliente { get; set; }

        public void registrar()
        {
            Console.WriteLine($"Qual os 4 primeiro numeros");
            this.Numero1 = Console.ReadLine();
            Console.WriteLine($"Qual os 4 segundo numeros");
            this.Numero2 = Console.ReadLine();
            Console.WriteLine($"Qual os 4 terceiro numeros");
            this.Numero3 = Console.ReadLine();
            Console.WriteLine($"Qual os 4 quarto numeros");
            this.Numero4 = Console.ReadLine();
            Console.WriteLine($"Qual o mes de vencimento");
            this.MesVencimento = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Qual o ano de vencimento");
            this.AnoVencimento = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Qual o CVC");
            this.CVC = Console.ReadLine();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CARTÃO DE CRÉDITO");
            sb.AppendLine("Número: " + Numero);
            sb.AppendLine("CVC: " + CVC);
            sb.AppendLine("Vencimento: " + Vencimento);
            sb.AppendLine("Cliente: " + Cliente.getNome());
            return sb.ToString();
        }
    }
}
