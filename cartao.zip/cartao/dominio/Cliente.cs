﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Cliente
    {
        public string Nome { get; set; }
        public string CPF { get; set; }
        public string RG { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CLIENTE");
            sb.AppendLine("Nome: " + Nome);
            sb.AppendLine("CPF: " + CPF);
            sb.AppendLine("RG: " + RG);

            return sb.ToString();
        }
    }
}
