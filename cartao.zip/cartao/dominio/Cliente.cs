﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Cliente
    {
        public String nome { get; set; }
        public DateTime dataAerturaConta { get; set; }
        public DateTime dataNascimento { get; set; }
        public String CPF { get; set; }
        public String RG { get; set; }
        public CartaoDeCredito cartao { get; set; }
    }
}
