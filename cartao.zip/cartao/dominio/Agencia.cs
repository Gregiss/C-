﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Agencia
    {
        public string Endereco { get; set; }
        public string numeroAgencia { get; set; }
        public Conta Conta { get; set; }

    }
}
