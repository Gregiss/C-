﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Agencia
    {
        public string Codigo { get; set; }
        public string Endereco { get; set; }
        public string Nome { get; set; }
        public Banco Banco { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("AGÊNCIA");
            sb.AppendLine("Código: " + Codigo);
            sb.AppendLine("Endereco: " + Endereco);
            sb.AppendLine("Nome: " + Nome);
            sb.AppendLine("Banco: " + Banco);
            return sb.ToString();
        }
    }
}
