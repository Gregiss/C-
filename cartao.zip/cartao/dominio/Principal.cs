﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Principal
    {
        public void cadastrar()
        {
            Boolean continua = true;
            var decisao = "no";
            int codigo = 0;
            while (continua)
            {
                Banco b = new Banco();
                b.Codigo = "001";
                b.Nome = "banco do Brasil";

                Agencia ag = new Agencia();
                ag.Banco = b;
                ag.Codigo = "0102";
                ag.Endereco = "Avenida das Comunidades, 100";
                ag.Nome = "Agência Banco Brasil Brusque";

                Cliente c = new Cliente();
                c.Nome = "Josefina Santos";
                c.CPF = "111.111.111-11";
                c.RG = "1.111.111-88";

                Conta conta = new Conta();
                conta.DigitoVerificador = "X";
                conta.Numero = "1456456";
                conta.Saldo = 0;
                conta.Titular = c;

                CartaoDeCredito cdc = new CartaoDeCredito();
                cdc.Cliente = c;
                cdc.AnoVencimento = 2022;
                cdc.CVC = "001";
                cdc.MesVencimento = 12;
                cdc.Numero1 = "1234";
                cdc.Numero2 = "5678";
                cdc.Numero3 = "9123";
                cdc.Numero4 = "4567";

                Console.WriteLine("BANCO: " + b.ToString());
                Console.WriteLine(ag.ToString());
                Console.WriteLine(conta.ToString());
                Console.WriteLine(cdc.Cliente.ToString());
                Console.WriteLine(cdc.ToString());
                Console.WriteLine("Você deseja cadastrar mais um cliente?\n yes or no");
                decisao = Console.ReadLine();
                if (decisao.Equals("yes"))
                {
                    continua = true;
                }
                else
                {
                    continua = false;  
                }
            }
        }

        public void navegar()
        {
            menu();
        }


        public void menu()
        {
            int oque = 0;
            while (true)
            {
                Console.WriteLine("Opções ?\n1:Cadastrar clientes");
                oque = Convert.ToInt32(Console.ReadLine());
                if (oque == 1)
                {
                    cadastrar();
                }
                else
                {
                    Console.WriteLine("Opção invalida");
                }
            }
        }

    }
}
