﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Principal
    {
        public void cadastrar()
        {
            Boolean continua = true;
            var decisao = "no";
            int codigo = 0;
            while (continua)
            {
                Cliente cli = new Cliente();
                Agencia ag = new Agencia();
                Conta conta = new Conta();
                Console.Write("Qual o nome do cliente:");
                cli.nome = Console.ReadLine();
                Console.Write($"Qual o CPF de {cli.nome} ");
                cli.CPF = Console.ReadLine();
                Console.Write($"Qual o RG de {cli.nome} ");
                cli.RG = Console.ReadLine();
                cli.dataAerturaConta = DateTime.Now;
                CartaoDeCredito cartao = new CartaoDeCredito();
                cartao.Cliente = cli;
                Console.Write($"Qual os 4 primeiro numeros do cartão de {cli.nome} ");
                cartao.Numero1 = Console.ReadLine();
                Console.Write($"Qual os 4 segundo numeros do cartão de {cli.nome} ");
                cartao.Numero2 = Console.ReadLine();
                Console.Write($"Qual os 4 terceiro numeros do cartão de {cli.nome} ");
                cartao.Numero3 = Console.ReadLine();
                Console.Write($"Qual os 4 quarto numeros do cartão de {cli.nome} ");
                cartao.Numero4 = Console.ReadLine();
                Console.Write($"Qual o CVC do cartão de {cli.nome}");
                cartao.CVC = Convert.ToInt32(Console.ReadLine());
                cartao.mesVencimento = DateTime.Now.Month + 5;
                cartao.anoVencimento = DateTime.Now.Year + 2;
                Console.WriteLine(cartao.mesVencimento + cartao.anoVencimento);
                cartao.nomeImpreso = cli.nome;
                cli.cartao = cartao;
                Console.Write("Qual o endereço: ");
                ag.Endereco = Console.ReadLine();
                conta.codigo = codigo;
                codigo++;
                conta.saldo = 0;
                conta.cliente = cli;
                conta.agencia = ag;
                Console.WriteLine("Você deseja cadastrar mais um cliente?\n yes or no");
                decisao = Console.ReadLine();
                if (decisao.Equals("yes"))
                {
                    continua = true;
                }
                else
                {
                    continua = false;  
                }
            }
        }

        public void navegar()
        {
            menu();
        }


        public void menu()
        {
            int oque = 0;
            while (true)
            {
                Console.WriteLine("Opções ?\n1:Cadastrar clientes");
                oque = Convert.ToInt32(Console.ReadLine());
                if (oque == 1)
                {
                    cadastrar();
                }
                else
                {
                    Console.WriteLine("Opção invalida");
                }
            }
        }

    }
}
