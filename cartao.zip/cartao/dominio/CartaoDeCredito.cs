﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class CartaoDeCredito
    {
        public string Numero1 { get; set; }
        public string Numero2 { get; set; }
        public string Numero3 { get; set; }
        public string Numero4 { get; set; }
        public string Numero
        {
            get
            {
                return $"{Numero1} {Numero2} {Numero3} {Numero4}";
            }
        }

        public int mesVencimento { get; set; }
        public int anoVencimento { get; set; }
        public string nomeImpreso { get; set; }
        public int CVC { get; set; }
        public Cliente Cliente { get; set; }
    }
}
