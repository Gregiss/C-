﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class CartaoDeCredito
    {
        public string Numero1 { get; set; }
        public string Numero2 { get; set; }
        public string Numero3 { get; set; }
        public string Numero4 { get; set; }
        public string Numero
        {
            get
            {
                return $"{Numero1} {Numero2} {Numero3} {Numero4}";
            }
        }

        public string CVC { get; set; }
        public int MesVencimento { get; set; }
        public int AnoVencimento { get; set; }
        public string Vencimento
        {
            get
            {
                return $"{MesVencimento}/{AnoVencimento}";
            }
        }

        public Cliente Cliente { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CARTÃO DE CRÉDITO");
            sb.AppendLine("Número: " + Numero);
            sb.AppendLine("CVC: " + CVC);
            sb.AppendLine("Vencimento: " + Vencimento);
            sb.AppendLine("Cliente: " + Cliente.Nome);
            return sb.ToString();
        }
    }
}
