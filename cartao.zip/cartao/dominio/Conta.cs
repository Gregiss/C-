﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Conta
    {
        public int codigo { get; set; }
        public int digitoVerificador { get; set; }
        public double saldo { get; set; }
        public Cliente cliente { get; set; }
        public Agencia agencia {get;set;}
    }
}
