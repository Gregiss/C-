﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cartao.dominio
{
    public class Conta
    {
        public string Numero { get; set; }
        public string DigitoVerificador { get; set; }
        public decimal Saldo { get; set; }
        public Cliente Titular { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CONTA CORRENTE");
            sb.AppendLine("Número: " + Numero + "/" + DigitoVerificador);
            sb.AppendLine("Saldo: " + Saldo.ToString("###,###,##0.00"));
            sb.AppendLine("Titular: " + Titular.Nome);
            return sb.ToString();
        }
    }
}
